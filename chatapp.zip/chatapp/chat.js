import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  TouchableWithoutFeedback,
  Keyboard,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import Ionicons from 'react-native-vector-icons/Ionicons';

SplashScreen.preventAutoHideAsync();

export default function ChatScreen({ route }) {
  const { otherUserId, otherUserName, profileImage } = route.params;
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [userId, setUserId] = useState(null);
  const flatListRef = useRef(null);
  const [loaded, error] = useFonts({
    'OpenSans-Bold': require('../assets/fonts/OpenSans-Bold.ttf'),
    'OpenSans-ExtraBold': require('../assets/fonts/OpenSans-ExtraBold.ttf'),
    'OpenSans-ExtraBoldItalic': require('../assets/fonts/OpenSans-ExtraBoldItalic.ttf'),
    'OpenSans-Italic': require('../assets/fonts/OpenSans-Italic.ttf'),
    'OpenSans-Medium': require('../assets/fonts/OpenSans-Medium.ttf'),
    'OpenSans-Regular': require('../assets/fonts/OpenSans-Regular.ttf'),
    'OpenSans-SemiBold': require('../assets/fonts/OpenSans-SemiBold.ttf'),
  });

  useEffect(() => {
    if (loaded || error) {
      SplashScreen.hideAsync();
    }
  }, [loaded, error]);

  if (!loaded && !error) {
    return null;
  }
  useEffect(() => {
    const loadUser = async () => {
      const id = await AsyncStorage.getItem('userId');
      setUserId(id);
    };
    loadUser();
  }, []);

 
  useEffect(() => {
    if (userId && otherUserId) {
      fetchChatHistory();

     
      const intervalId = setInterval(() => {
        fetchChatHistory();
      }, 2000);

      
      return () => clearInterval(intervalId);
    }
  }, [userId, otherUserId]);

  
  const fetchChatHistory = async () => {
    try {
      const response = await fetch(
        `https://40be-112-134-198-204.ngrok-free.app/LiveChat/LoadChat?logged_user_id=${userId}&other_user_id=${otherUserId}`
      );

      if (!response.ok) {
        console.error(`Server error: ${response.statusText}`);
        return;
      }

      const data = await response.json();
      if (Array.isArray(data)) {
        setMessages(data);
        flatListRef.current?.scrollToEnd({ animated: true });
      }
    } catch (error) {
      console.error('Error loading chat history:', error);
    }
  };

 
  const handleSend = async () => {
    if (message.trim()) {
      try {
        const response = await fetch(
          `https://40be-112-134-198-204.ngrok-free.app/LiveChat/SendChat?logged_user_id=${userId}&other_user_id=${otherUserId}&message=${message}`,
          { method: 'GET' }
        );

        const data = await response.json();

        if (data.success) {
          
          setMessages(prevMessages => [
            ...prevMessages,
            { from_user: userId, message, date_time: new Date().toString(), side: 'received' },
          ]);
          setMessage(''); 
          flatListRef.current?.scrollToEnd({ animated: true }); 
        }
      } catch (error) {
        console.error('Error sending message:', error);
      }
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <SafeAreaView style={styles.safeArea}>
        <View style={styles.header}>
  <View style={styles.profileContainer}>
    <Image source={{ uri: profileImage }} style={styles.profileImage} />
    <View style={styles.onlineIndicator} />
  </View>
  <Text style={styles.headerTitle}>{otherUserName}</Text>
</View>


<FlatList
  ref={flatListRef}
  data={messages}
  keyExtractor={(item, index) => index.toString()}
  renderItem={({ item }) => (
    <View
      style={[
        styles.messageContainer,
        item.side === 'sent' ? styles.sent : styles.received,
      ]}
    >
      <Text style={styles.messageText}>{item.message}</Text>
      <Text style={styles.timestamp}>
        {new Date(item.datetime).toLocaleString()}
      </Text>
      {item.side === 'received' && (
        <Text style={styles.seen}>seen</Text>
      )}
    </View>
  )}
  style={styles.messagesList}
  onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
/>

          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={message}
              onChangeText={setMessage}
              placeholder="Type a message..."
            />
           <TouchableOpacity onPress={handleSend} style={styles.sendButton}>
  <Ionicons name="send" size={22} color="#1a1a42" />
</TouchableOpacity>
          </View>
        </SafeAreaView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    fontFamily:'OpenSans-SemiBold',
  },
  profileImage: {
    width: 72,
    height: 72,
    borderRadius: 20,
    marginRight: 10,
    borderColor:'#1a1a42',
  },
  headerTitle: {
    fontSize: 21,
    fontWeight: 'bold',
    alignItems:'center',
    justifyContent:'center',
  },
  seen:{
    fontSize: 11,
   alignItems:"flex-end",
  },
  messagesList: {
    flex: 1,
    padding: 10,
  },
  messageContainer: {
    padding: 10,
    borderRadius: 10,
    marginVertical: 5,
    maxWidth: "85%",
  },
  sent: {
    alignSelf: 'flex-start',
    backgroundColor: '#6A9AB0',
  },
  received: {
    alignSelf: 'flex-end',
    backgroundColor: '#9AC8CD',
  },
  messageText: {
    fontSize: 16,
    fontFamily:'OpenSans-SemiBold',
  },
  timestamp: {
    fontSize: 12,
    color: 'black',
    marginTop: 5,
    fontFamily:'OpenSans-Regular',
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 13,
    borderTopWidth: 1.2,
    borderTopColor: '#E0E0E0',
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#1a1a42',
    borderRadius: 20,
    paddingHorizontal: 15,
    height:50,
    width:30,
  },
  sendButton: {
    backgroundColor: 'none',
    borderRadius: 10,
    padding: 15,
    marginLeft: 6,
    height:50,
    width:60,
    alignItems:'center',
    marginLeft: 6,
  },
  sendButtonText: {
    color: '#FFF',
    textAlign:"center",
    fontWeight: 'bold',
  },
  text:{
  
  },
  onlineIndicator: {
    position: 'absolute',
    bottom: 1,
    right: 17,
    width: 13,
    height: 13,
    borderRadius: 10,
    backgroundColor: 'green',
    borderWidth: 2,
    borderColor: '#fff', 
  },
});
