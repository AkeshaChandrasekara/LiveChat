import React, { useState, useEffect } from 'react'; 
import { View, Text, TouchableOpacity, Image, StyleSheet,
   StatusBar, SafeAreaView, KeyboardAvoidingView, TouchableWithoutFeedback, 
   Keyboard, ScrollView, Platform } from 'react-native';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';

SplashScreen.preventAutoHideAsync();

const StartScreen = ({ navigation }) => {
  const [loaded, error] = useFonts({
    'OpenSans-Bold': require('../assets/fonts/OpenSans-Bold.ttf'),
    'OpenSans-ExtraBold': require('../assets/fonts/OpenSans-ExtraBold.ttf'),
    'OpenSans-ExtraBoldItalic': require('../assets/fonts/OpenSans-ExtraBoldItalic.ttf'),
    'OpenSans-Italic': require('../assets/fonts/OpenSans-Italic.ttf'),
    'OpenSans-Medium': require('../assets/fonts/OpenSans-Medium.ttf'),
    'OpenSans-Regular': require('../assets/fonts/OpenSans-Regular.ttf'),
    'OpenSans-SemiBold': require('../assets/fonts/OpenSans-SemiBold.ttf'),
  });

  useEffect(() => {
    if (loaded || error) {
      SplashScreen.hideAsync();
    }
  }, [loaded, error]);

  if (!loaded && !error) {
    return null;
  }

  return (
    <KeyboardAvoidingView style={styles.safeArea} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <SafeAreaView style={styles.safeArea}>
          <StatusBar hidden={true} />
          <ScrollView contentContainerStyle={styles.scrollViewContent}>
            <View style={styles.container}>
            
        
            <Image source={require('../assets/back.png')} style={styles.chatImage} />
              <Image source={require('../assets/icon1.jpg')} style={styles.icon} />

              <Text style={styles.title}>Where Conversations Come Alive!</Text>
              <Text style={styles.paragraph}>
                LiveChat makes it easy to connect and chat with friends, family, and colleagues in real time.
                Our user-friendly app enhances your conversations, making them more engaging and enjoyable.
                Whether you're catching up, sharing ideas, or collaborating on projects, LiveChat ensures every message counts.
                Join us and experience lively conversations like never before!
              </Text>
              <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('SignIn')}>
                <Text style={styles.buttonText}>Let's Start</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </SafeAreaView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollViewContent: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
  },
  icon: {
    width: 150,
    height: 120,
    marginBottom: 5,
  },
  chatImage: {
    width: 330,
    height: 285,
    marginBottom: 1,
  },
  title: {
    fontFamily: 'OpenSans-ExtraBoldItalic',
    fontSize: 33,
    color: '#1a1a42',
    marginBottom: 0.1,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#1a1a42',
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 15,
    width: 355,
  },
  buttonText: {
    color: '#FFFFFF',
    fontFamily: 'OpenSans-Bold',
    fontSize: 20,
  },
  paragraph: {
    fontSize: 16,
    lineHeight: 24,
    textAlign: 'justify',
    color: '#333',
    fontFamily: 'OpenSans-Regular',
  },
});

export default StartScreen;
