import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  StatusBar,
  SafeAreaView,
  KeyboardAvoidingView,
  TouchableWithoutFeedback,
  Keyboard,
  ScrollView,
  Platform,
} from 'react-native';
import { registerRootComponent } from 'expo';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';

SplashScreen.preventAutoHideAsync();

const formatDate = (dateString) => {
  const date = new Date(dateString);
  if (isNaN(date.getTime())) {
    return 'Invalid date';
  }
  return date.toLocaleString(); 
};

export default function ChatHome() {
  const [searchText, setSearchText] = useState('');
  const [chats, setChats] = useState([]);
  const [filteredChats, setFilteredChats] = useState([]);
  const navigation = useNavigation();

  const [loaded, error] = useFonts({
    'OpenSans-Bold': require('../assets/fonts/OpenSans-Bold.ttf'),
    'OpenSans-ExtraBold': require('../assets/fonts/OpenSans-ExtraBold.ttf'),
    'OpenSans-Italic': require('../assets/fonts/OpenSans-Italic.ttf'),
    'OpenSans-Regular': require('../assets/fonts/OpenSans-Regular.ttf'),
  });

  useEffect(() => {
    const fetchChats = async () => {
      try {
        const userId = await AsyncStorage.getItem('userId');
        if (userId) {
          const response = await fetch(`https://40be-112-134-198-204.ngrok-free.app/LiveChat/Home?id=${userId}`);
          const data = await response.json();

          if (data.success) {
            const fetchedChats = data.jsonChatArray.map(chat => ({
              id: chat.other_user_id,
              name: chat.other_user_name,
              message: chat.message,
              time: formatDate(chat.dateTime),
              seen: chat.chat_status_id === 1,
              profileImage: chat.avatar_image_found ? `https://40be-112-134-198-204.ngrok-free.app/LiveChat/images/${chat.other_user_mobile}.png` : null,
              onlineStatus: chat.other_user_status === 1,
            }));

            fetchedChats.sort((a, b) => new Date(b.time) - new Date(a.time));
            setChats(fetchedChats);
            setFilteredChats(fetchedChats);
          }
        }
      } catch (error) {
        console.error('Error fetching chat data:', error);
      }
    };

    fetchChats();
  }, []);


  useEffect(() => {
    const filterChats = () => {
      const filtered = chats.filter(chat =>
        chat.name.toLowerCase().includes(searchText.toLowerCase())
      );
      setFilteredChats(filtered);
    };
    filterChats();
  }, [searchText, chats]);

  useEffect(() => {
    if (loaded || error) {
      SplashScreen.hideAsync();
    }
  }, [loaded, error]);

  const handleChatPress = (chat) => {
    navigation.navigate('Chat', {
      otherUserId: chat.id,
      otherUserName: chat.name,
      profileImage: chat.profileImage,
      onlineStatus: chat.onlineStatus,
    });
  };

  if (!loaded && !error) {
    return null;
  }

  return (
    <KeyboardAvoidingView style={styles.safeArea} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <SafeAreaView style={styles.safeArea}>
          <StatusBar hidden={true} />
          <ScrollView contentContainerStyle={styles.scrollViewContent}>
            <View style={styles.container}>
              <Image source={require('../assets/icon1.jpg')} style={styles.chatLogo} />
              <Text style={styles.title}>Where Conversations Come Alive!</Text>
              <TextInput 
                style={styles.searchInput} 
                placeholder="Search Freinds..." 
                value={searchText} 
                onChangeText={setSearchText} 
              />
              <View style={styles.chatList}>
                {filteredChats.map(chat => (
                  <TouchableOpacity key={chat.id} style={styles.chatItem} onPress={() => handleChatPress(chat)}>
                    <View style={styles.profileImageContainer}>
                      <Image source={{ uri: chat.profileImage }} style={styles.profileImage} />
                      <View style={[styles.statusIndicator, { backgroundColor: chat.onlineStatus ? 'green' : 'red' }]} />
                    </View>
                    <View style={styles.chatInfoContainer}>
                      <Text style={styles.chatName}>{chat.name}</Text>
                      <Text style={styles.chatMessage}>{chat.message}</Text>
                      <View style={styles.chatInfo}>
                        <Text style={styles.chatTime}>{chat.time}</Text> 
                        <Text style={styles.chatSeen}>{chat.seen ? '✓✓' : '✓'}</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </ScrollView>
        </SafeAreaView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollViewContent: {
    flexGrow: 1,
    justifyContent: 'flex-start',
  },
  container: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
  },
  title: {
    fontFamily: 'OpenSans-ExtraBoldItalic',
    fontSize: 21,
    color: '#1a1a42',
   // marginBottom: 5,
    textAlign: 'center',
    marginTop:2,
  },
  chatLogo: {
    width: 120,
    height: 120,
    marginBottom: 20,
  },
  searchInput: {
    width: '100%',
    height: 50,
    borderColor: '#1a1a42',
    borderWidth: 1.3,
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 10,
    fontFamily: 'OpenSans-Regular',
    fontSize:15,
    color:'black',
  },
  chatList: {
    width: '100%',
    flexGrow: 1,
  },
  chatItem: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileImageContainer: {
    position: 'relative',
    marginRight: 15,
  },
  profileImage: {
    width: 72,
    height: 72,
    borderRadius: 25,
  },
  statusIndicator: {
    position: 'absolute',
    right: -5,
    bottom: -5,
    width: 12,
    height: 12,
    borderRadius: 5,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  chatInfoContainer: {
    flex: 1,
  },
  chatName: {
    fontFamily: 'OpenSans-Bold',
    fontSize: 18,
    color: '#1a1a42',
  },
  chatMessage: {
    fontFamily: 'OpenSans-Regular',
    fontSize: 16,
    color: 'black',
  },
  chatInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 5,
  },
  chatTime: {
    fontFamily: 'OpenSans-Regular',
    fontSize: 13,
    color: 'black',
  },
  chatSeen: {
    fontFamily: 'OpenSans-Regular',
    fontSize: 12,
    color: 'red',
  },
});

registerRootComponent(ChatHome);
