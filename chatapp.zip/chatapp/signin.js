import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, StyleSheet, StatusBar, SafeAreaView, KeyboardAvoidingView, TouchableWithoutFeedback, Keyboard, ScrollView, Platform, Alert } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFonts } from 'expo-font';

SplashScreen.preventAutoHideAsync();

export default function Signin({ navigation }) {
  const [loaded, error] = useFonts({
    'OpenSans-Bold': require('../assets/fonts/OpenSans-Bold.ttf'),
    'OpenSans-ExtraBold': require('../assets/fonts/OpenSans-ExtraBold.ttf'),
    'OpenSans-Italic': require('../assets/fonts/OpenSans-Italic.ttf'),
    'OpenSans-Regular': require('../assets/fonts/OpenSans-Regular.ttf'),
    'OpenSans-Medium': require('../assets/fonts/OpenSans-Medium.ttf'),
    'OpenSans-SemiBold': require('../assets/fonts/OpenSans-SemiBold.ttf'),
  });

  useEffect(() => {
    async function checkUserInAsyncStorage() {
      try {
        let userJson = await AsyncStorage.getItem("user");
        if (userJson != null) {
         // navigation.navigate('Home');
         
        }
      } catch (e) {
        console.log(e);
      }
    }

    checkUserInAsyncStorage();
  }, [navigation]);
  
  useEffect(() => {
    if (loaded || error) {
      SplashScreen.hideAsync();
    }
  }, [loaded, error]);

  if (!loaded && !error) {
    return null;
  }

  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');

  const handleSignIn = async () => {
    try {
      const response = await fetch('https://40be-112-134-198-204.ngrok-free.app/LiveChat/SignIn', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ mobile, password }),
      });

      if (response.ok) {
        const json = await response.json();

        if (json.success) {
          const user = json.user;
          Alert.alert("Success", "Hi " + user.first_name + ", " + json.message);
          
          await AsyncStorage.setItem("userId", user.id.toString()); 
          await AsyncStorage.setItem("user", JSON.stringify(user));

          setMobile(''); 
          setPassword(''); 
          navigation.navigate('Home'); 
        } else {
          Alert.alert("Error", json.message);
        }
      } else {
        Alert.alert("Error", "Failed to sign in. Please try again.");
      }
    } catch (error) {
      Alert.alert("Error", "Unable to process your request. Please check your network connection.");
      console.error("Sign-in error:", error);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.safeArea} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <SafeAreaView style={styles.safeArea}>
          <StatusBar hidden={true} />
          <ScrollView contentContainerStyle={styles.scrollViewContent}>
            <View style={styles.container}>
              <Image source={require('../assets/chat_image.png')} style={styles.chatImage} />

              <Text style={styles.title}>LiveChat</Text>
              <Text style={styles.subtitle}>Login Here</Text>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>Mobile</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your mobile number"
                  keyboardType="phone-pad"
                  value={mobile}
                  onChangeText={setMobile}
                />

                <Text style={styles.label}>Password</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your password"
                  secureTextEntry
                  value={password}
                  onChangeText={setPassword}
                />

                <TouchableOpacity style={styles.button} onPress={handleSignIn}>
                  <Text style={styles.buttonText}>Sign In</Text>
                </TouchableOpacity>
              </View>

              <Text style={styles.signInText}>
                Haven't an Account? <Text style={styles.signInLink} onPress={() => navigation.navigate('SignUp')}>Create Account</Text>
              </Text>
            </View>
          </ScrollView>
        </SafeAreaView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollViewContent: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
  },
  chatImage: {
    width: 280,
    height: 280,
    marginBottom: 1,
  },
  icon: {
    width: 150,
    height: 120,
    marginBottom: 5,
  },
  title: {
    fontFamily: 'OpenSans-ExtraBoldItalic',
    fontSize: 38,
    color: '#1a1a42',
    marginBottom: 1,
    textAlign: 'center',
  },
  subtitle: {
    fontFamily: 'OpenSans-Bold',
    fontSize: 25,
    color: '#1a1a42',
    marginBottom: 4,
    textAlign: 'left',
    width: '100%', 
    paddingHorizontal: 1,  
  },
  inputContainer: {
    width: '100%',
    marginBottom: 10,
  },
  label: {
    fontFamily: 'OpenSans-Medium',
    fontSize: 16,
    color: '#1a1a42',
    marginBottom: 10,
  },
  input: {
    width: '100%',
    height: 50,
    borderColor: '#1a1a42',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 10,
    fontFamily: 'OpenSans-Regular',
  },
  button: {
    backgroundColor: '#1a1a42',
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 5, 
  },
  buttonText: {
    color: '#FFFFFF',
    fontFamily: 'OpenSans-Bold',
    fontSize: 18,
  },
  signInText: {
    fontFamily: 'OpenSans-Regular',
    fontSize: 18,
    color: '#666',
    marginTop: 3,  
    textAlign: 'center',
  },
  signInLink: {
    color: '#1a1a42',
    fontFamily: 'OpenSans-Bold',
  },
});
