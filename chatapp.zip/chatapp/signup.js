import React, { useState, useEffect } from 'react'; 
import { registerRootComponent } from "expo";
import { View, Text, TextInput, TouchableOpacity, Image, StyleSheet, StatusBar,
  SafeAreaView, KeyboardAvoidingView, TouchableWithoutFeedback, Keyboard, 
  ScrollView, Platform,
  Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';

SplashScreen.preventAutoHideAsync();

export default function Signup({navigation}) {
  const [image, setImage] = useState(null);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');

  const [loaded, error] = useFonts({
    'OpenSans-Bold': require('../assets/fonts/OpenSans-Bold.ttf'),
    'OpenSans-ExtraBold': require('../assets/fonts/OpenSans-ExtraBold.ttf'),
    'OpenSans-ExtraBoldItalic': require('../assets/fonts/OpenSans-ExtraBoldItalic.ttf'),
    'OpenSans-Italic': require('../assets/fonts/OpenSans-Italic.ttf'),
    'OpenSans-Medium': require('../assets/fonts/OpenSans-Medium.ttf'),
    'OpenSans-Regular': require('../assets/fonts/OpenSans-Regular.ttf'),
    'OpenSans-SemiBold': require('../assets/fonts/OpenSans-SemiBold.ttf'),
  });

  useEffect(() => {
    if (loaded || error) {
      SplashScreen.hideAsync();
    }
  }, [loaded, error]);

  if (!loaded && !error) {
    return null;
  }



  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const handleSignup = async () => {
    const formData = new FormData();
    formData.append('firstName', firstName);
    formData.append('lastName', lastName);
    formData.append('mobile', mobile);
    formData.append('password', password);
  
    //set image as default image
    let imageUri = image || 'file://' + require('../assets/profile.jpg');
    formData.append('image', {
      uri: imageUri,
      name: image ? 'profile.png' : 'default_profile.jpg',
      type: 'image/png',
    });
  
    try {
      const response = await fetch("https://40be-112-134-198-204.ngrok-free.app/LiveChat/SignUp", { 
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'multipart/form-data',
        },
      });
  
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Server responded with status ${response.status}: ${errorText}`);
      }
  
      const responseJson = await response.json();
  
      if (responseJson.success) {
        Alert.alert('Success', responseJson.message);
        setFirstName('');
        setLastName('');
        setMobile('');
        setPassword('');
        setImage(null);
       navigation.navigate('SignIn');
      } else {
        Alert.alert('Error', responseJson.message);
      }
    } catch (error) {
      console.error("Error during signup:", error);
      Alert.alert('Error', error.message || 'Network request failed');
    }
  };
  

  return (
    <KeyboardAvoidingView style={styles.safeArea} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <SafeAreaView style={styles.safeArea}>
          <StatusBar hidden={true} />
          <ScrollView contentContainerStyle={styles.scrollViewContent}>
            <View style={styles.container}>
              <Image source={require('../assets/chat_image.png')} style={styles.chatImage} />
              <Text style={styles.title}>LiveChat</Text>
              <Text style={styles.subtitle}>Create Your Account</Text>
              
              <TouchableOpacity onPress={pickImage}>
                <Image
                  source={image ? { uri: image } : require('../assets/profile.jpg')}
                  style={styles.profileImage}
                />
              </TouchableOpacity>

              <View style={styles.inputContainer}>
                <Text style={styles.label}>First Name</Text>
                <TextInput style={styles.input} placeholder="Enter your first name" value={firstName} onChangeText={setFirstName} />

                <Text style={styles.label}>Last Name</Text>
                <TextInput style={styles.input} placeholder="Enter your last name" value={lastName} onChangeText={setLastName} />

                <Text style={styles.label}>Mobile</Text>
                <TextInput style={styles.input} placeholder="Enter your mobile number" keyboardType="phone-pad" value={mobile} onChangeText={setMobile} />

                <Text style={styles.label}>Password</Text>
                <TextInput style={styles.input} placeholder="Enter your password" secureTextEntry value={password} onChangeText={setPassword} />

                <TouchableOpacity style={styles.button} onPress={handleSignup}>
                  <Text style={styles.buttonText}>Sign Up</Text>
                </TouchableOpacity>
              </View>

              <Text style={styles.signInText}>
                Already Have an Account? <Text style={styles.signInLink}  onPress={() => navigation.navigate('SignIn')} >Sign In</Text>
              </Text>
            </View>
          </ScrollView>
        </SafeAreaView>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  scrollViewContent: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
  },
  chatImage: {
    width: 230,
    height: 230,
    marginBottom: 0.3,
  },
  title: {
    fontFamily: 'OpenSans-ExtraBoldItalic',
    fontSize: 38,
    color: '#1a1a42',
    marginBottom: 0.1,
    textAlign: 'center',
  },
  subtitle: {
    fontFamily: 'OpenSans-Bold',
    fontSize: 20,
    color: '#1a1a42',
    marginBottom: 4,
    textAlign: 'left',
    width: '100%', 
    paddingHorizontal: 1,  
  },
  profileImage: {
    width: 95,
    height: 95,
    borderRadius: 60,
    backgroundColor: '#e0e0e0',
    marginBottom: 5,
  },
  inputContainer: {
    width: '100%',
    marginBottom: 5,
  },
  label: {
    fontFamily: 'OpenSans-Medium',
    fontSize: 16,
    color: '#1a1a42',
    marginBottom: 5,
  },
  input: {
    width: '100%',
    height: 50,
    borderColor: '#1a1a42',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 6,
    fontFamily: 'OpenSans-Regular',
  },
  button: {
    backgroundColor: '#1a1a42',
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontFamily: 'OpenSans-Bold',
    fontSize: 18,
  },
  signInText: {
    fontFamily: 'OpenSans-Regular',
    fontSize: 18,
    color: '#666',
    marginTop: 0.1,  
    textAlign: 'center',
  },
  signInLink: {
    color: '#1a1a42',
    fontFamily: 'OpenSans-Bold',
  },
});

registerRootComponent(Signup);
